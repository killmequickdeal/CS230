"""When run sets the file so the only thing stores is the total drops at zero
essentially resetting the drops gotten
Author: Riley Deal
Created: 4/26/15
CSCI 23000 Final Project
"""
import pickle#import pickle
dropNumber=0#set total drops to zero

f = open("dropper.dat", "wb")#open in write binary

pickle.dump(dropNumber, f)#save

f.close#close
