EXL__ is the font type for better aesthetics
D3DropLogger is the main file
resetDropNumber resets the .dat file the items are stored in
the word doc is for documentation
item folder stores the pictures