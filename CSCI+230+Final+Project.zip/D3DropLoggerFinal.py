"""Show Total Amount of Recieved Drops as well as the % of each item recieved in relation to the total
Author: Riley Deal
Created: 4/26/15
CSCI 23000 Final Project
For supposed drop rates: https://docs.google.com/spreadsheets/d/1cM-s4e66ql2zsrkfkfKXmvVJ4zmngzxdzVLk9gvLvT8/htmlview?usp=sharing&sle=true#
"""

#ONLY the first 6 item subsets (first 3 rows) actually increment variables
#The rest of the items could easily be coded the exact same way, but with time restraints i could not finish all of them

from tkinter import *#import tkinter to create gui
import pickle#import pickle to store variables across sessions


class dropLog(Tk):
    def __init__(self, number = -1):#number is imported as -1 so that on the initialization no items get added, it must be an int so assigning a non int value causes an int -> str error
        Tk.__init__(self)#initialize tk
        #initialize the font, title, classes
        self.headerFont = ("Exocet Light", "10", "bold")
        self.title("Diablo 3 Drop Logger")
        self.makeLegendaryButtons()
        #initialize TopLevel window variable
        self.newWindow = ""
        self.count(number)


        #create list to append buttons to
        self.showBtns = []
        #create tuple of names to iterate through 
        self.showChoices1 = ("Axes","Daggers","Maces","Spears","Swords","Ceremonial Knives","Fist Weapons","Flails","Mighty Weapons"
                            ,"2h Axes","2h Maces","Polearms","2h Staffs","2h Swords", "2h Flails","2h Mighty Weapons","Helmets","Spirit Stones",
                            "Voodoo Masks","Diabos","Belts","Mighty Belts","Pants","Boots","Amulets","Rings",
                            "Shields","Crusader Shields","Mojos","Orbs","Quivers","Follower Items","Miscellaneous","Wizard Hats","Shoulders","Chestplates",
                             "Cloaks","Bracers","Gloves")
         
        for i in range(len(self.showChoices1)):#grid all pictures at once by iterating through the tuple
            self.showBtns.append(Button(self, text=self.showChoices1[i],font=self.headerFont,fg="#e6e600", bg="#595959"))
            self.showBtns[i]["command"]=lambda i = i: self.makeButtons(i)
            self.showBtns[i].grid(row=i//2, column = i%2,sticky="we")
        #grid the total items 
        Label(self, text="Total Drops: {}".format(self.__dropNumber)).grid(row=19,column=1)

    def makeLegendaryButtons(self):#import all the pictures needed from the specified file
        self.diabo1 = PhotoImage(file="items\diabo1.gif")
        self.diabo2 = PhotoImage(file="items\diabo2.gif")
        self.diabo3 = PhotoImage(file="items\diabo3.gif")
        self.diabo4 = PhotoImage(file="items\diabo4.gif")
        self.diabo5 = PhotoImage(file="items\diabo5.gif")
        self.diabo6 = PhotoImage(file="items\diabo6.gif")
        self.diabo7 = PhotoImage(file="items\diabo7.gif")
        self.diabo8 = PhotoImage(file="items\diabo8.gif")
        self.axe1 = PhotoImage(file="items\Axe1.gif")
        self.axe2 = PhotoImage(file="items\Axe2.gif")
        self.axe3 = PhotoImage(file="items\Axe3.gif")
        self.axe4 = PhotoImage(file="items\Axe4.gif")
        self.axe5 = PhotoImage(file="items\Axe5.gif")
        self.axe6 = PhotoImage(file="items\Axe6.gif")
        self.dagger1 = PhotoImage(file="items\dagger1.gif")
        self.dagger2 = PhotoImage(file="items\dagger2.gif")
        self.dagger3 = PhotoImage(file="items\dagger3.gif")
        self.dagger4 = PhotoImage(file="items\dagger4.gif")
        self.dagger5 = PhotoImage(file="items\dagger5.gif")
        self.mace1 = PhotoImage(file="items\mace1.gif")
        self.mace2 = PhotoImage(file="items\mace2.gif")
        self.mace3 = PhotoImage(file="items\mace3.gif")
        self.mace4 = PhotoImage(file="items\mace4.gif")
        self.mace5 = PhotoImage(file="items\mace5.gif")
        self.mace6 = PhotoImage(file="items\mace6.gif")
        self.mace7 = PhotoImage(file="items\mace7.gif")
        self.mace8 = PhotoImage(file="items\mace8.gif")
        self.mace9 = PhotoImage(file="items\mace9.gif")
        self.spear1 = PhotoImage(file="items\spear1.gif")
        self.spear2 = PhotoImage(file="items\spear2.gif")
        self.spear3 = PhotoImage(file="items\spear3.gif")
        self.spear4 = PhotoImage(file="items\spear4.gif")
        self.spear5 = PhotoImage(file="items\spear5.gif")
        self.sword1 = PhotoImage(file="items\sword1.gif")
        self.sword2 = PhotoImage(file="items\sword2.gif")
        self.sword3 = PhotoImage(file="items\sword3.gif")
        self.sword4 = PhotoImage(file="items\sword4.gif")
        self.sword5 = PhotoImage(file="items\sword5.gif")
        self.sword6 = PhotoImage(file="items\sword6.gif")
        self.sword7 = PhotoImage(file="items\sword7.gif")
        self.sword8 = PhotoImage(file="items\sword8.gif")
        self.sword9 = PhotoImage(file="items\sword9.gif")
        self.sword10 = PhotoImage(file="items\sword10.gif")
        self.sword11 = PhotoImage(file="items\sword11.gif")
        self.sword12 = PhotoImage(file="items\sword12.gif")
        self.sword13 = PhotoImage(file="items\sword13.gif")
        self.sword14 = PhotoImage(file="items\sword14.gif")
        self.sword15 = PhotoImage(file="items\sword15.gif")
        self.sword16 = PhotoImage(file="items\sword16.gif")
        self.sword17 = PhotoImage(file="items\sword17.gif")
        self.ck1 = PhotoImage(file="items\ck1.gif")
        self.ck2 = PhotoImage(file="items\ck2.gif")
        self.ck3 = PhotoImage(file="items\ck3.gif")
        self.ck4 = PhotoImage(file="items\ck4.gif")
        self.ck5 = PhotoImage(file="items\ck5.gif")
        self.ck6 = PhotoImage(file="items\ck6.gif")
        self.ck7 = PhotoImage(file="items\ck7.gif")
        self.ck8 = PhotoImage(file="items\ck8.gif")
        self.ck9 = PhotoImage(file="items\ck9.gif")
        self.ck10 = PhotoImage(file="items\ck10.gif")
        self.fist1 = PhotoImage(file="items\wfist1.gif")
        self.fist2 = PhotoImage(file="items\wfist2.gif")
        self.fist3 = PhotoImage(file="items\wfist3.gif")
        self.fist4 = PhotoImage(file="items\wfist4.gif")
        self.fist5 = PhotoImage(file="items\wfist5.gif")
        self.fist6 = PhotoImage(file="items\wfist6.gif")
        self.fist7 = PhotoImage(file="items\wfist7.gif")
        self.fist8 = PhotoImage(file="items\wfist8.gif")
        self.fist9 = PhotoImage(file="items\wfist9.gif")
        self.fist10 = PhotoImage(file="items\wfist10.gif")
        self.fist11 = PhotoImage(file="items\wfist11.gif")
        self.fist12 = PhotoImage(file="items\wfist12.gif")
        self.flail1 = PhotoImage(file="items\wflail1.gif")
        self.flail2 = PhotoImage(file="items\wflail2.gif")
        self.flail3 = PhotoImage(file="items\wflail3.gif")
        self.flail4 = PhotoImage(file="items\wflail4.gif")
        self.flail5 = PhotoImage(file="items\wflail5.gif")
        self.flail6 = PhotoImage(file="items\wflail6.gif")
        self.mighty1 = PhotoImage(file="items\mighty1.gif")
        self.mighty2 = PhotoImage(file="items\mighty2.gif")
        self.mighty3 = PhotoImage(file="items\mighty3.gif")
        self.mighty4 = PhotoImage(file="items\mighty4.gif")
        self.mighty5 = PhotoImage(file="items\mighty5.gif")
        self.mighty6 = PhotoImage(file="items\mighty6.gif")
        self.axe2h1 = PhotoImage(file="items\Axe2h1.gif")
        self.axe2h2 = PhotoImage(file="items\Axe2h2.gif")
        self.axe2h3 = PhotoImage(file="items\Axe2h3.gif")
        self.axe2h4 = PhotoImage(file="items\Axe2h4.gif")
        self.mace2h1 = PhotoImage(file="items\mace2h1.gif")
        self.mace2h2 = PhotoImage(file="items\mace2h2.gif")
        self.mace2h3 = PhotoImage(file="items\mace2h3.gif")
        self.mace2h4 = PhotoImage(file="items\mace2h4.gif")
        self.mace2h5 = PhotoImage(file="items\mace2h5.gif")
        self.mace2h6 = PhotoImage(file="items\mace2h6.gif")
        self.mace2h7 = PhotoImage(file="items\mace2h7.gif")
        self.polearm1 = PhotoImage(file="items\polearm1.gif")
        self.polearm2 = PhotoImage(file="items\polearm2.gif")
        self.polearm3 = PhotoImage(file="items\polearm3.gif")
        self.polearm4 = PhotoImage(file="items\polearm4.gif")
        self.polearm5 = PhotoImage(file="items\polearm5.gif")
        self.staff1 = PhotoImage(file="items\staff1.gif")
        self.staff2 = PhotoImage(file="items\staff2.gif")
        self.staff3 = PhotoImage(file="items\staff3.gif")
        self.staff4 = PhotoImage(file="items\staff4.gif")
        self.staff5 = PhotoImage(file="items\staff5.gif")
        self.staff6 = PhotoImage(file="items\staff6.gif")
        self.staff7 = PhotoImage(file="items\staff7.gif")
        self.staff8 = PhotoImage(file="items\staff8.gif")
        self.staff9 = PhotoImage(file="items\staff9.gif")
        self.sword2h1 = PhotoImage(file="items\sword2h1.gif")
        self.sword2h2 = PhotoImage(file="items\sword2h2.gif")
        self.sword2h3 = PhotoImage(file="items\sword2h3.gif")
        self.sword2h4 = PhotoImage(file="items\sword2h4.gif")
        self.sword2h5 = PhotoImage(file="items\sword2h5.gif")
        self.sword2h6 = PhotoImage(file="items\sword2h6.gif")
        self.sword2h7 = PhotoImage(file="items\sword2h7.gif")
        self.sword2h8 = PhotoImage(file="items\sword2h8.gif")
        self.sword2h9 = PhotoImage(file="items\sword2h9.gif")
        self.sword2h10 = PhotoImage(file="items\sword2h10.gif")
        self.sword2h11 = PhotoImage(file="items\sword2h11.gif")
        self.sword2h12 = PhotoImage(file="items\sword2h12.gif")
        self.sword2h13 = PhotoImage(file="items\sword2h13.gif")
        self.flail2h1 = PhotoImage(file="items\wflail2h1.gif")
        self.flail2h2 = PhotoImage(file="items\wflail2h2.gif")
        self.flail2h3 = PhotoImage(file="items\wflail2h3.gif")
        self.flail2h4 = PhotoImage(file="items\wflail2h4.gif")
        self.might2h1 = PhotoImage(file="items\mighty2h1.gif")
        self.might2h2 = PhotoImage(file="items\mighty2h2.gif")
        self.might2h3 = PhotoImage(file="items\mighty2h3.gif")
        self.might2h4 = PhotoImage(file="items\mighty2h4.gif")
        self.might2h5 = PhotoImage(file="items\mighty2h5.gif")
        self.helm1 = PhotoImage(file="items\helm1.gif")
        self.helm2 = PhotoImage(file="items\helm2.gif")
        self.helm3 = PhotoImage(file="items\helm3.gif")
        self.helm4 = PhotoImage(file="items\helm4.gif")
        self.helm5 = PhotoImage(file="items\helm5.gif")
        self.helm6 = PhotoImage(file="items\helm6.gif")
        self.helm7 = PhotoImage(file="items\helm7.gif")
        self.helm8 = PhotoImage(file="items\helm8.gif")
        self.helm9 = PhotoImage(file="items\helm9.gif")
        self.helm10 = PhotoImage(file="items\helm10.gif")
        self.helm11 = PhotoImage(file="items\helm11.gif")
        self.helm12 = PhotoImage(file="items\helm12.gif")
        self.helm13 = PhotoImage(file="items\helm13.gif")
        self.helm14 = PhotoImage(file="items\helm14.gif")
        self.helm15 = PhotoImage(file="items\helm15.gif")
        self.helm16 = PhotoImage(file="items\helm16.gif")
        self.helm17 = PhotoImage(file="items\helm17.gif")
        self.helm18 = PhotoImage(file="items\helm18.gif")
        self.helm19 = PhotoImage(file="items\helm19.gif")
        self.helm20 = PhotoImage(file="items\helm20.gif")
        self.helm21 = PhotoImage(file="items\helm21.gif")
        self.helm22 = PhotoImage(file="items\helm22.gif")
        self.helm23 = PhotoImage(file="items\helm23.gif")
        self.helm24 = PhotoImage(file="items\helm24.gif")
        self.spirit1 = PhotoImage(file="items\spirit1.gif")
        self.spirit2 = PhotoImage(file="items\spirit2.gif")
        self.spirit3 = PhotoImage(file="items\spirit3.gif")
        self.spirit4 = PhotoImage(file="items\spirit4.gif")
        self.spirit5 = PhotoImage(file="items\spirit5.gif")
        self.spirit6 = PhotoImage(file="items\spirit6.gif")
        self.spirit7 = PhotoImage(file="items\spirit7.gif")
        self.spirit8 = PhotoImage(file="items\spirit8.gif")
        self.spirit9 = PhotoImage(file="items\spirit9.gif")
        self.spirit10 = PhotoImage(file="items\spirit10.gif")
        self.spirit11 = PhotoImage(file="items\spirit11.gif")
        self.spirit12 = PhotoImage(file="items\spirit12.gif")
        self.voodoo1 = PhotoImage(file="items\Voodoo1.gif")
        self.voodoo2 = PhotoImage(file="items\Voodoo2.gif")
        self.voodoo3 = PhotoImage(file="items\Voodoo3.gif")
        self.voodoo4 = PhotoImage(file="items\Voodoo4.gif")
        self.voodoo5 = PhotoImage(file="items\Voodoo5.gif")
        self.voodoo6 = PhotoImage(file="items\Voodoo6.gif")
        self.voodoo7 = PhotoImage(file="items\Voodoo7.gif")
        self.voodoo8 = PhotoImage(file="items\Voodoo8.gif")
        self.wizhat1 = PhotoImage(file="items\wizhat1.gif")
        self.wizhat2 = PhotoImage(file="items\wizhat2.gif")
        self.wizhat3 = PhotoImage(file="items\wizhat3.gif")
        self.wizhat4 = PhotoImage(file="items\wizhat4.gif")
        self.wizhat5 = PhotoImage(file="items\wizhat5.gif")
        self.wizhat6 = PhotoImage(file="items\wizhat6.gif")
        self.wizhat7 = PhotoImage(file="items\wizhat7.gif")
        self.shoulder1 = PhotoImage(file="items\shoulder1.gif")
        self.shoulder2 = PhotoImage(file="items\shoulder2.gif")
        self.shoulder3 = PhotoImage(file="items\shoulder3.gif")
        self.shoulder4 = PhotoImage(file="items\shoulder4.gif")
        self.shoulder5 = PhotoImage(file="items\shoulder5.gif")
        self.shoulder6 = PhotoImage(file="items\shoulder6.gif")
        self.shoulder7 = PhotoImage(file="items\shoulder7.gif")
        self.shoulder8 = PhotoImage(file="items\shoulder8.gif")
        self.shoulder9 = PhotoImage(file="items\shoulder9.gif")
        self.shoulder10 = PhotoImage(file="items\shoulder10.gif")
        self.shoulder11 = PhotoImage(file="items\shoulder11.gif")
        self.shoulder12 = PhotoImage(file="items\shoulder12.gif")
        self.shoulder13 = PhotoImage(file="items\shoulder13.gif")
        self.shoulder14 = PhotoImage(file="items\shoulder14.gif")
        self.shoulder15 = PhotoImage(file="items\shoulder15.gif")
        self.shoulder16 = PhotoImage(file="items\shoulder16.gif")
        self.shoulder17 = PhotoImage(file="items\shoulder17.gif")
        self.shoulder18 = PhotoImage(file="items\shoulder18.gif")
        self.shoulder19 = PhotoImage(file="items\shoulder19.gif")
        self.chest1 = PhotoImage(file="items\chest1.gif")
        self.chest2 = PhotoImage(file="items\chest2.gif")
        self.chest3 = PhotoImage(file="items\chest3.gif")
        self.chest4 = PhotoImage(file="items\chest4.gif")
        self.chest5 = PhotoImage(file="items\chest5.gif")
        self.chest6 = PhotoImage(file="items\chest6.gif")
        self.chest7 = PhotoImage(file="items\chest7.gif")
        self.chest8 = PhotoImage(file="items\chest8.gif")
        self.chest9 = PhotoImage(file="items\chest9.gif")
        self.chest10 = PhotoImage(file="items\chest10.gif")
        self.chest11 = PhotoImage(file="items\chest11.gif")
        self.chest12 = PhotoImage(file="items\chest12.gif")
        self.chest13 = PhotoImage(file="items\chest13.gif")
        self.chest14 = PhotoImage(file="items\chest14.gif")
        self.chest15 = PhotoImage(file="items\chest15.gif")
        self.chest16 = PhotoImage(file="items\chest16.gif")
        self.chest17 = PhotoImage(file="items\chest17.gif")
        self.chest18 = PhotoImage(file="items\chest18.gif")
        self.chest19 = PhotoImage(file="items\chest19.gif")
        self.chest20 = PhotoImage(file="items\chest20.gif")
        self.chest21 = PhotoImage(file="items\chest21.gif")
        self.chest22 = PhotoImage(file="items\chest22.gif")
        self.chest23 = PhotoImage(file="items\chest23.gif")
        self.chest24 = PhotoImage(file="items\chest24.gif")
        self.chest25 = PhotoImage(file="items\chest25.gif")
        self.cloak1 = PhotoImage(file="items\cloak1.gif")
        self.cloak2 = PhotoImage(file="items\cloak2.gif")
        self.cloak3 = PhotoImage(file="items\cloak3.gif")
        self.cloak4 = PhotoImage(file="items\cloak4.gif")
        self.cloak5 = PhotoImage(file="items\cloak5.gif")
        self.cloak6 = PhotoImage(file="items\cloak6.gif")
        self.bracers1 = PhotoImage(file="items\Bracers1.gif")
        self.bracers2 = PhotoImage(file="items\Bracers2.gif")
        self.bracers3 = PhotoImage(file="items\Bracers3.gif")
        self.bracers4 = PhotoImage(file="items\Bracers4.gif")
        self.bracers5 = PhotoImage(file="items\Bracers5.gif")
        self.bracers6 = PhotoImage(file="items\Bracers6.gif")
        self.bracers7 = PhotoImage(file="items\Bracers7.gif")
        self.bracers8 = PhotoImage(file="items\Bracers8.gif")
        self.bracers9 = PhotoImage(file="items\Bracers9.gif")
        self.bracers10 = PhotoImage(file="items\Bracers10.gif")
        self.bracers11 = PhotoImage(file="items\Bracers11.gif")
        self.bracers12 = PhotoImage(file="items\Bracers12.gif")
        self.bracers13 = PhotoImage(file="items\Bracers13.gif")
        self.bracers14 = PhotoImage(file="items\Bracers14.gif")
        self.bracers15 = PhotoImage(file="items\Bracers15.gif")
        self.gloves1 = PhotoImage(file="items\gloves1.gif")
        self.gloves2 = PhotoImage(file="items\gloves2.gif")
        self.gloves3 = PhotoImage(file="items\gloves3.gif")
        self.gloves4 = PhotoImage(file="items\gloves4.gif")
        self.gloves5 = PhotoImage(file="items\gloves5.gif")
        self.gloves6 = PhotoImage(file="items\gloves6.gif")
        self.gloves7 = PhotoImage(file="items\gloves7.gif")
        self.gloves8 = PhotoImage(file="items\gloves8.gif")
        self.gloves9 = PhotoImage(file="items\gloves9.gif")
        self.gloves10 = PhotoImage(file="items\gloves10.gif")
        self.gloves11 = PhotoImage(file="items\gloves11.gif")
        self.gloves12 = PhotoImage(file="items\gloves12.gif")
        self.gloves13 = PhotoImage(file="items\gloves13.gif")
        self.gloves14 = PhotoImage(file="items\gloves14.gif")
        self.gloves15 = PhotoImage(file="items\gloves15.gif")
        self.gloves16 = PhotoImage(file="items\gloves16.gif")
        self.gloves17 = PhotoImage(file="items\gloves17.gif")
        self.gloves18 = PhotoImage(file="items\gloves18.gif")
        self.gloves19 = PhotoImage(file="items\gloves19.gif")
        self.gloves20 = PhotoImage(file="items\gloves20.gif")
        self.gloves21 = PhotoImage(file="items\gloves21.gif")
        self.gloves22 = PhotoImage(file="items\gloves22.gif")
        self.gloves23 = PhotoImage(file="items\gloves23.gif")
        self.gloves24 = PhotoImage(file="items\gloves24.gif")
        self.gloves25 = PhotoImage(file="items\gloves25.gif")
        self.gloves26 = PhotoImage(file="items\gloves26.gif")
        self.gloves27 = PhotoImage(file="items\gloves27.gif")
        self.belt1 = PhotoImage(file="items\Belt1.gif")
        self.belt2 = PhotoImage(file="items\Belt2.gif")
        self.belt3 = PhotoImage(file="items\Belt3.gif")
        self.belt4 = PhotoImage(file="items\Belt4.gif")
        self.belt5 = PhotoImage(file="items\Belt5.gif")
        self.belt6 = PhotoImage(file="items\Belt6.gif")
        self.belt7 = PhotoImage(file="items\Belt7.gif")
        self.belt8 = PhotoImage(file="items\Belt8.gif")
        self.belt9 = PhotoImage(file="items\Belt9.gif")
        self.belt10 = PhotoImage(file="items\Belt10.gif")
        self.belt11 = PhotoImage(file="items\Belt11.gif")
        self.belt12 = PhotoImage(file="items\Belt12.gif")
        self.belt13 = PhotoImage(file="items\Belt13.gif")
        self.belt14 = PhotoImage(file="items\Belt14.gif")
        self.belt15 = PhotoImage(file="items\Belt15.gif")
        self.belt16 = PhotoImage(file="items\Belt16.gif")
        self.belt17 = PhotoImage(file="items\Belt17.gif")
        self.belt18 = PhotoImage(file="items\Belt18.gif")
        self.belt19 = PhotoImage(file="items\Belt19.gif")
        self.belt20 = PhotoImage(file="items\Belt20.gif")
        self.belt21 = PhotoImage(file="items\Belt21.gif")
        self.belt22 = PhotoImage(file="items\Belt22.gif")
        self.belt23 = PhotoImage(file="items\Belt23.gif")
        self.belt24 = PhotoImage(file="items\Belt24.gif")
        self.belt25 = PhotoImage(file="items\Belt25.gif")
        self.belt26 = PhotoImage(file="items\Belt26.gif")
        self.mightbelt1 = PhotoImage(file="items\mightybelt1.gif")
        self.mightbelt2 = PhotoImage(file="items\mightybelt2.gif")
        self.mightbelt3 = PhotoImage(file="items\mightybelt3.gif")
        self.mightbelt4 = PhotoImage(file="items\mightybelt4.gif")
        self.mightbelt5 = PhotoImage(file="items\mightybelt5.gif")
        self.mightbelt6 = PhotoImage(file="items\mightybelt6.gif")
        self.mightbelt7 = PhotoImage(file="items\mightybelt7.gif")
        self.mightbelt8 = PhotoImage(file="items\mightybelt8.gif")
        self.pants1 = PhotoImage(file="items\pants1.gif")
        self.pants2 = PhotoImage(file="items\pants2.gif")
        self.pants3 = PhotoImage(file="items\pants3.gif")
        self.pants4 = PhotoImage(file="items\pants4.gif")
        self.pants5 = PhotoImage(file="items\pants5.gif")
        self.pants6 = PhotoImage(file="items\pants6.gif")
        self.pants7 = PhotoImage(file="items\pants7.gif")
        self.pants8 = PhotoImage(file="items\pants8.gif")
        self.pants9 = PhotoImage(file="items\pants9.gif")
        self.pants10 = PhotoImage(file="items\pants10.gif")
        self.pants11 = PhotoImage(file="items\pants11.gif")
        self.pants12 = PhotoImage(file="items\pants12.gif")
        self.pants13 = PhotoImage(file="items\pants13.gif")
        self.pants14 = PhotoImage(file="items\pants14.gif")
        self.pants15 = PhotoImage(file="items\pants15.gif")
        self.pants16 = PhotoImage(file="items\pants16.gif")
        self.pants17 = PhotoImage(file="items\pants17.gif")
        self.pants18 = PhotoImage(file="items\pants18.gif")
        self.pants19 = PhotoImage(file="items\pants19.gif")
        self.pants20 = PhotoImage(file="items\pants20.gif")
        self.pants21 = PhotoImage(file="items\pants21.gif")
        self.pants22 = PhotoImage(file="items\pants22.gif")
        self.boots1 = PhotoImage(file="items\Boots1.gif")
        self.boots2 = PhotoImage(file="items\Boots2.gif")
        self.boots3 = PhotoImage(file="items\Boots3.gif")
        self.boots4 = PhotoImage(file="items\Boots4.gif")
        self.boots5 = PhotoImage(file="items\Boots5.gif")
        self.boots6 = PhotoImage(file="items\Boots6.gif")
        self.boots7 = PhotoImage(file="items\Boots7.gif")
        self.boots8 = PhotoImage(file="items\Boots8.gif")
        self.boots9 = PhotoImage(file="items\Boots9.gif")
        self.boots10 = PhotoImage(file="items\Boots10.gif")
        self.boots11 = PhotoImage(file="items\Boots11.gif")
        self.boots12 = PhotoImage(file="items\Boots12.gif")
        self.boots13 = PhotoImage(file="items\Boots13.gif")
        self.boots14 = PhotoImage(file="items\Boots14.gif")
        self.boots15 = PhotoImage(file="items\Boots15.gif")
        self.boots16 = PhotoImage(file="items\Boots16.gif")
        self.boots17 = PhotoImage(file="items\Boots17.gif")
        self.boots18 = PhotoImage(file="items\Boots18.gif")
        self.boots19 = PhotoImage(file="items\Boots19.gif")
        self.boots20 = PhotoImage(file="items\Boots20.gif")
        self.boots21 = PhotoImage(file="items\Boots21.gif")
        self.boots22 = PhotoImage(file="items\Boots22.gif")
        self.boots23 = PhotoImage(file="items\Boots23.gif")
        self.boots24 = PhotoImage(file="items\Boots24.gif")
        self.boots25 = PhotoImage(file="items\Boots25.gif")
        self.amulet1 = PhotoImage(file="items\Amulet1.gif")
        self.amulet2 = PhotoImage(file="items\Amulet2.gif")
        self.amulet3 = PhotoImage(file="items\Amulet3.gif")
        self.amulet4 = PhotoImage(file="items\Amulet4.gif")
        self.amulet5 = PhotoImage(file="items\Amulet5.gif")
        self.amulet6 = PhotoImage(file="items\Amulet6.gif")
        self.amulet7 = PhotoImage(file="items\Amulet7.gif")
        self.amulet8 = PhotoImage(file="items\Amulet8.gif")
        self.amulet9 = PhotoImage(file="items\Amulet9.gif")
        self.amulet10 = PhotoImage(file="items\Amulet10.gif")
        self.amulet11 = PhotoImage(file="items\Amulet11.gif")
        self.amulet12 = PhotoImage(file="items\Amulet12.gif")
        self.amulet13 = PhotoImage(file="items\Amulet13.gif")
        self.amulet14 = PhotoImage(file="items\Amulet14.gif")
        self.amulet15 = PhotoImage(file="items\Amulet15.gif")
        self.amulet16 = PhotoImage(file="items\Amulet16.gif")
        self.amulet17 = PhotoImage(file="items\Amulet17.gif")
        self.amulet18 = PhotoImage(file="items\Amulet18.gif")
        self.amulet19 = PhotoImage(file="items\Amulet19.gif")
        self.amulet20 = PhotoImage(file="items\Amulet20.gif")
        self.amulet21 = PhotoImage(file="items\Amulet21.gif")
        self.amulet22 = PhotoImage(file="items\Amulet22.gif")
        self.amulet23 = PhotoImage(file="items\Amulet23.gif")
        self.ring1 = PhotoImage(file="items\Ring1.gif")
        self.ring2 = PhotoImage(file="items\Ring2.gif")
        self.ring3 = PhotoImage(file="items\Ring3.gif")
        self.ring4 = PhotoImage(file="items\Ring4.gif")
        self.ring5 = PhotoImage(file="items\Ring5.gif")
        self.ring6 = PhotoImage(file="items\Ring6.gif")
        self.ring7 = PhotoImage(file="items\Ring7.gif")
        self.ring8 = PhotoImage(file="items\Ring8.gif")
        self.ring9 = PhotoImage(file="items\Ring9.gif")
        self.ring10 = PhotoImage(file="items\Ring10.gif")
        self.ring11 = PhotoImage(file="items\Ring11.gif")
        self.ring12 = PhotoImage(file="items\Ring12.gif")
        self.ring13 = PhotoImage(file="items\Ring13.gif")
        self.ring14 = PhotoImage(file="items\Ring14.gif")
        self.ring15 = PhotoImage(file="items\Ring15.gif")
        self.ring16 = PhotoImage(file="items\Ring16.gif")
        self.ring17 = PhotoImage(file="items\Ring17.gif")
        self.ring18 = PhotoImage(file="items\Ring18.gif")
        self.ring19 = PhotoImage(file="items\Ring19.gif")
        self.ring20 = PhotoImage(file="items\Ring20.gif")
        self.ring21 = PhotoImage(file="items\Ring21.gif")
        self.ring22 = PhotoImage(file="items\Ring22.gif")
        self.ring23 = PhotoImage(file="items\Ring23.gif")
        self.ring24 = PhotoImage(file="items\Ring24.gif")
        self.ring25 = PhotoImage(file="items\Ring25.gif")
        self.ring26 = PhotoImage(file="items\Ring26.gif")
        self.ring27 = PhotoImage(file="items\Ring27.gif")
        self.ring28 = PhotoImage(file="items\Ring28.gif")
        self.ring29 = PhotoImage(file="items\Ring29.gif")
        self.ring30 = PhotoImage(file="items\Ring30.gif")
        self.ring31 = PhotoImage(file="items\Ring31.gif")
        self.ring32 = PhotoImage(file="items\Ring32.gif")
        self.shield1 = PhotoImage(file="items\shield1.gif")
        self.shield2 = PhotoImage(file="items\shield2.gif")
        self.shield3 = PhotoImage(file="items\shield3.gif")
        self.shield4 = PhotoImage(file="items\shield4.gif")
        self.shield5 = PhotoImage(file="items\shield5.gif")
        self.shield6 = PhotoImage(file="items\shield6.gif")
        self.shield7 = PhotoImage(file="items\shield7.gif")
        self.shield8 = PhotoImage(file="items\shield8.gif")
        self.crusshield1 = PhotoImage(file="items\crusshield1.gif")
        self.crusshield2 = PhotoImage(file="items\crusshield2.gif")
        self.crusshield3 = PhotoImage(file="items\crusshield3.gif")
        self.crusshield4 = PhotoImage(file="items\crusshield4.gif")
        self.crusshield5 = PhotoImage(file="items\crusshield5.gif")
        self.crusshield6 = PhotoImage(file="items\crusshield6.gif")
        self.crusshield7 = PhotoImage(file="items\crusshield7.gif")
        self.crusshield8 = PhotoImage(file="items\crusshield8.gif")
        self.mojo1 = PhotoImage(file="items\mojo1.gif")
        self.mojo2 = PhotoImage(file="items\mojo2.gif")
        self.mojo3 = PhotoImage(file="items\mojo3.gif")
        self.mojo4 = PhotoImage(file="items\mojo4.gif")
        self.mojo5 = PhotoImage(file="items\mojo5.gif")
        self.mojo6 = PhotoImage(file="items\mojo6.gif")
        self.mojo7 = PhotoImage(file="items\mojo7.gif")
        self.orb1 = PhotoImage(file="items\orb1.gif")
        self.orb2 = PhotoImage(file="items\orb2.gif")
        self.orb3 = PhotoImage(file="items\orb3.gif")
        self.orb4 = PhotoImage(file="items\orb4.gif")
        self.orb5 = PhotoImage(file="items\orb5.gif")
        self.orb6 = PhotoImage(file="items\orb6.gif")
        self.orb7 = PhotoImage(file="items\orb7.gif")
        self.orb8 = PhotoImage(file="items\orb8.gif")
        self.orb9 = PhotoImage(file="items\orb9.gif")
        self.quiver1 = PhotoImage(file="items\quiver1.gif")
        self.quiver2 = PhotoImage(file="items\quiver2.gif")
        self.quiver3 = PhotoImage(file="items\quiver3.gif")
        self.quiver4 = PhotoImage(file="items\quiver4.gif")
        self.quiver5 = PhotoImage(file="items\quiver5.gif")
        self.quiver6 = PhotoImage(file="items\quiver6.gif")
        self.quiver7 = PhotoImage(file="items\quiver7.gif")
        self.quiver8 = PhotoImage(file="items\quiver8.gif")
        self.quiver9 = PhotoImage(file="items\quiver9.gif")
        self.follower1 = PhotoImage(file="items\wfollower1.gif")
        self.follower2 = PhotoImage(file="items\wfollower2.gif")
        self.follower3 = PhotoImage(file="items\wfollower3.gif")
        self.misc1 = PhotoImage(file="items\misc1.gif")
        self.misc2 = PhotoImage(file="items\misc2.gif")
        self.bow1 = PhotoImage(file="items\Bow1.gif")
        self.bow2 = PhotoImage(file="items\Bow2.gif")
        self.bow3 = PhotoImage(file="items\Bow3.gif")
        self.bow4 = PhotoImage(file="items\Bow4.gif")
        self.bow5 = PhotoImage(file="items\Bow5.gif")
        self.bow6 = PhotoImage(file="items\Bow6.gif")
        self.bow7 = PhotoImage(file="items\Bow7.gif")
        self.bow8 = PhotoImage(file="items\Bow8.gif")
        self.xbow2h1 = PhotoImage(file="items\wxbow2h1.gif")
        self.xbow2h2 = PhotoImage(file="items\wxbow2h2.gif")
        self.xbow2h3 = PhotoImage(file="items\wxbow2h3.gif")
        self.xbow2h4 = PhotoImage(file="items\wxbow2h4.gif")
        self.xbow2h5 = PhotoImage(file="items\wxbow2h5.gif")
        self.xbow2h6 = PhotoImage(file="items\wxbow2h6.gif")
        self.xbow2h7 = PhotoImage(file="items\wxbow2h7.gif")
        self.xbow2h8 = PhotoImage(file="items\wxbow2h8.gif")
        self.xbow1 = PhotoImage(file="items\crossbow1.gif")
        self.xbow2 = PhotoImage(file="items\crossbow2.gif")
        self.xbow3 = PhotoImage(file="items\crossbow3.gif")
        self.xbow4 = PhotoImage(file="items\crossbow4.gif")
        self.xbow5 = PhotoImage(file="items\crossbow5.gif")
        self.xbow6 = PhotoImage(file="items\crossbow6.gif")
        self.xbow7 = PhotoImage(file="items\crossbow7.gif")
        self.xbow8 = PhotoImage(file="items\crossbow8.gif")
        self.wand1 = PhotoImage(file="items\wand1.gif")
        self.wand2 = PhotoImage(file="items\wand2.gif")
        self.wand3 = PhotoImage(file="items\wand3.gif")
        self.wand4 = PhotoImage(file="items\wand4.gif")
        self.wand5 = PhotoImage(file="items\wand5.gif")
        self.wand6 = PhotoImage(file="items\wand6.gif")
        self.wand7 = PhotoImage(file="items\wand7.gif")
        self.wand8 = PhotoImage(file="items\wand8.gif")
        self.wand9 = PhotoImage(file="items\wand9.gif")

    def makeButtons(self,item):#start to make new buttons by creating the TopLevel which they will open into
        self.newWindow = Toplevel(self)
        if item==0:#all of these are the same as before; make a list to append to, make a tuple of images this time to iterate through
            self.axeBtns = []
            self.axePictures = (self.axe1,self.axe2,self.axe3,self.axe4,self.axe5,self.axe6)
            for i in range(len(self.axePictures)):
                self.axeBtns.append(Button(self.newWindow, image=self.axePictures[i],bg="#835121"))
                self.axeBtns[i]["command"]=lambda i = i: self.count(i)#command goes to the count function for i
                self.axeBtns[i].image=self.axePictures[i]
                self.axeBtns[i].grid(row=1, column = i)
            #append the drop rates of the items
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe6total/self.__dropNumber))).grid(row=11,column=5)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe1total/self.__dropNumber))).grid(row=11,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe2total/self.__dropNumber))).grid(row=11,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe3total/self.__dropNumber))).grid(row=11,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe4total/self.__dropNumber))).grid(row=11,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe5total/self.__dropNumber))).grid(row=11,column=4)

        if item==1:
            self.daggerBtns = []
            self.daggerPictures = (self.dagger1,self.dagger2,self.dagger3,self.dagger4,self.dagger5)
            for i in range(len(self.daggerPictures)):
                self.daggerBtns.append(Button(self.newWindow, image=self.daggerPictures[i],bg="#835121"))
                self.daggerBtns[i]["command"]=lambda i = i: self.count(i+15)
                self.daggerBtns[i].image=self.daggerPictures[i]
                self.daggerBtns[i].grid(row=1, column = i)

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger1total/self.__dropNumber))).grid(row=11,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger2total/self.__dropNumber))).grid(row=11,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger3total/self.__dropNumber))).grid(row=11,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger4total/self.__dropNumber))).grid(row=11,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger5total/self.__dropNumber))).grid(row=11,column=4)

        if item==2:
            self.maceBtns = []
            self.macePictures = (self.mace1,self.mace2,self.mace3,self.mace4,self.mace5,self.mace6,self.mace7,self.mace8,self.mace9)
            for i in range(len(self.macePictures)):
                self.maceBtns.append(Button(self.newWindow, image=self.macePictures[i],bg="#835121"))
                self.maceBtns[i]["command"]=lambda i = i: self.count(i+6)
                self.maceBtns[i].image=self.macePictures[i]
                self.maceBtns[i].grid(row=1, column = i)

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace1total/self.__dropNumber))).grid(row=11,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace2total/self.__dropNumber))).grid(row=11,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace3total/self.__dropNumber))).grid(row=11,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace4total/self.__dropNumber))).grid(row=11,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace5total/self.__dropNumber))).grid(row=11,column=4)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace6total/self.__dropNumber))).grid(row=11,column=5)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace7total/self.__dropNumber))).grid(row=11,column=6)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace8total/self.__dropNumber))).grid(row=11,column=7)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace9total/self.__dropNumber))).grid(row=11,column=8)

        if item==3:
            self.spearBtns = []
            self.spearPictures = (self.spear1,self.spear2,self.spear3,self.spear4,self.spear5)
            for i in range(len(self.spearPictures)):
                self.spearBtns.append(Button(self.newWindow, image=self.spearPictures[i],bg="#835121"))
                self.spearBtns[i]["command"]=lambda i = i: self.count(i+21)
                self.spearBtns[i].image=self.spearPictures[i]
                self.spearBtns[i].grid(row=1, column = i)

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear1total/self.__dropNumber))).grid(row=11,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear2total/self.__dropNumber))).grid(row=11,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear3total/self.__dropNumber))).grid(row=11,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear4total/self.__dropNumber))).grid(row=11,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear5total/self.__dropNumber))).grid(row=11,column=4)

        if item==4:
            
            self.swordBtns = []
            self.swordPictures = (self.sword1,self.sword2,self.sword3,self.sword4,self.sword5,self.sword6,self.sword7,self.sword8,self.sword9,self.sword10,
                                  self.sword11,self.sword12,self.sword13,self.sword14,self.sword15)
            for i in range(len(self.swordPictures)):
                self.swordBtns.append(Button(self.newWindow, image=self.swordPictures[i],bg="#835121"))
                self.swordBtns[i]["command"]=lambda i = i: self.count(i+26)
                self.swordBtns[i].image=self.swordPictures[i]
                self.swordBtns[i].grid(row=1+(i%2), column = i//2)

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword1total/self.__dropNumber))).grid(row=0,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword2total/self.__dropNumber))).grid(row=3,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword3total/self.__dropNumber))).grid(row=0,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword4total/self.__dropNumber))).grid(row=3,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword5total/self.__dropNumber))).grid(row=0,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword6total/self.__dropNumber))).grid(row=3,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword7total/self.__dropNumber))).grid(row=0,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword8total/self.__dropNumber))).grid(row=3,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword9total/self.__dropNumber))).grid(row=0,column=4)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword10total/self.__dropNumber))).grid(row=3,column=4)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword11total/self.__dropNumber))).grid(row=0,column=5)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword12total/self.__dropNumber))).grid(row=3,column=5)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword13total/self.__dropNumber))).grid(row=0,column=6)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword14total/self.__dropNumber))).grid(row=3,column=6)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword15total/self.__dropNumber))).grid(row=0,column=7)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword16total/self.__dropNumber))).grid(row=3,column=7)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword17total/self.__dropNumber))).grid(row=0,column=8)
            #some append the 'green' items separately since there are very few of them as opposed to making a separate tuple
            self.btn = Button(self.newWindow, image=self.sword16, bg="#569522", command = lambda: self.count(42))
            self.btn.image=self.sword16
            self.btn.grid(row=1,column=8)

            self.btn = Button(self.newWindow, image=self.sword17, bg="#569522", command = lambda: self.count(41))
            self.btn.image=self.sword17
            self.btn.grid(row=2,column=7)

        if item==5:
            self.ckBtns = []
            self.ckPictures = (self.ck1,self.ck2,self.ck3,self.ck4,self.ck5,self.ck6,self.ck7,self.ck8,self.ck9)
            for i in range(len(self.ckPictures)):
                self.ckBtns.append(Button(self.newWindow, image=self.ckPictures[i],bg="#835121"))
                self.ckBtns[i]["command"]=lambda i = i: self.count(i+43)
                self.ckBtns[i].image=self.ckPictures[i]
                self.ckBtns[i].grid(row=1+(i%2), column = i//2)

            self.btn = Button(self.newWindow, image=self.ck10, bg="#569522", command = lambda: self.count(52))
            self.btn.image=self.ck10
            self.btn.grid(row=1,column=4)

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck1total/self.__dropNumber))).grid(row=0,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck2total/self.__dropNumber))).grid(row=3,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck3total/self.__dropNumber))).grid(row=0,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck4total/self.__dropNumber))).grid(row=3,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck5total/self.__dropNumber))).grid(row=0,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck6total/self.__dropNumber))).grid(row=3,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck7total/self.__dropNumber))).grid(row=0,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck8total/self.__dropNumber))).grid(row=3,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck9total/self.__dropNumber))).grid(row=0,column=4)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck10total/self.__dropNumber))).grid(row=0,column=4)

        if item==6:#after this point the drop rates are not displayed, but are just the same thing over and over again, not difficult.
            self.fistBtns = []
            self.fistPictures = (self.fist1,self.fist2,self.fist3,self.fist4,self.fist5,self.fist6,self.fist7,self.fist8,self.fist9,self.fist10)
            for i in range(len(self.fistPictures)):
                self.fistBtns.append(Button(self.newWindow, image=self.fistPictures[i],bg="#835121"))
                #self.fistBtns[i]["command"]=lambda i = i: self.count(i)
                self.fistBtns[i].image=self.fistPictures[i]
                self.fistBtns[i].grid(row=i%2, column = i//2)

            self.btn = Button(self.newWindow, image=self.fist11, bg="#569522")
            self.btn.image=self.fist11
            self.btn.grid(row=1,column=19)

            self.btn = Button(self.newWindow, image=self.fist12, bg="#569522")
            self.btn.image=self.fist12
            self.btn.grid(row=0,column=19)

        if item==7:
            self.flailBtns = []
            self.flailPictures = (self.flail1,self.flail2,self.flail3,self.flail4,self.flail5,self.flail6)
            for i in range(len(self.flailPictures)):
                self.flailBtns.append(Button(self.newWindow, image=self.flailPictures[i],bg="#835121"))
                #self.flailBtns[i]["command"]=lambda i = i: self.count(i)
                self.flailBtns[i].image=self.flailPictures[i]
                self.flailBtns[i].grid(row=1, column = i+2)

        if item==8:
            self.mightyWeaponBtns = []
            self.mightyWeaponPictures = (self.mighty1,self.mighty2,self.mighty3,self.mighty4)
            for i in range(len(self.mightyWeaponPictures)):
                self.mightyWeaponBtns.append(Button(self.newWindow, image=self.mightyWeaponPictures[i],bg="#835121"))
                #self.mightyWeaponBtns[i]["command"]=lambda i = i: self.count(i)
                self.mightyWeaponBtns[i].image=self.mightyWeaponPictures[i]
                self.mightyWeaponBtns[i].grid(row=1, column = i+2)

            self.btn = Button(self.newWindow, image=self.mighty5, bg="#569522")
            self.btn.image=self.mighty5
            self.btn.grid(row=1,column=19)

            self.btn = Button(self.newWindow, image=self.mighty6, bg="#569522")
            self.btn.image=self.mighty6
            self.btn.grid(row=1,column=20)

        if item==9:
            self.hAxeBtns = []
            self.hAxePictures = (self.axe2h1,self.axe2h2,self.axe2h3,self.axe2h4)
            for i in range(len(self.hAxePictures)):
                self.hAxeBtns.append(Button(self.newWindow, image=self.hAxePictures[i],bg="#835121"))
                #self.hAxeBtns[i]["command"]=lambda i = i: self.count(i)
                self.hAxeBtns[i].image=self.hAxePictures[i]
                self.hAxeBtns[i].grid(row=1, column = i+2)

        if item==10:
            self.hMaceBtns = []
            self.hMacePictures = (self.mace2h1,self.mace2h2,self.mace2h3,self.mace2h4,self.mace2h5,self.mace2h6,self.mace2h7)
            for i in range(len(self.hMacePictures)):
                self.hMaceBtns.append(Button(self.newWindow, image=self.hMacePictures[i],bg="#835121"))
                #self.hMaceBtns[i]["command"]=lambda i = i: self.count(i)
                self.hMaceBtns[i].image=self.hMacePictures[i]
                self.hMaceBtns[i].grid(row=1, column = i+2)

        if item==11:
            self.polearmBtns = []
            self.polearmPictures = (self.polearm1,self.polearm2,self.polearm3,self.polearm4,self.polearm5)
            for i in range(len(self.polearmPictures)):
                self.polearmBtns.append(Button(self.newWindow, image=self.polearmPictures[i],bg="#835121"))
                #self.polearmBtns[i]["command"]=lambda i = i: self.count(i)
                self.polearmBtns[i].image=self.polearmPictures[i]
                self.polearmBtns[i].grid(row=1, column = i+2)

        if item==12:
            self.hStaffBtns = []
            self.hStaffPictures = (self.staff1,self.staff2,self.staff3,self.staff4,self.staff5,self.staff6,self.staff7,self.staff8,self.staff9)
            for i in range(len(self.hStaffPictures)):
                self.hStaffBtns.append(Button(self.newWindow, image=self.hStaffPictures[i],bg="#835121"))
                #self.hStaffBtns[i]["command"]=lambda i = i: self.count(i)
                self.hStaffBtns[i].image=self.hStaffPictures[i]
                self.hStaffBtns[i].grid(row=1, column = i+2)

        if item==13:
            self.hSwordBtns = []
            self.hSwordPictures = (self.sword2h1,self.sword2h2,self.sword2h3,self.sword2h4,self.sword2h5,self.sword2h6,self.sword2h7,self.sword2h8,self.sword2h9,
                                   self.sword2h10,self.sword2h11,self.sword2h12,self.sword2h13)
            for i in range(len(self.hSwordPictures)):
                self.hSwordBtns.append(Button(self.newWindow, image=self.hSwordPictures[i],bg="#835121"))
                #self.hSwordBtns[i]["command"]=lambda i = i: self.count(i)
                self.hSwordBtns[i].image=self.hSwordPictures[i]
                self.hSwordBtns[i].grid(row=i%2, column = i//2)

        if item==14:
            self.hFlailBtns = []
            self.hFlailPictures = (self.flail2h1,self.flail2h2,self.flail2h3,self.flail2h4)
            for i in range(len(self.hFlailPictures)):
                self.hFlailBtns.append(Button(self.newWindow, image=self.hFlailPictures[i],bg="#835121"))
                #self.hFlailBtns[i]["command"]=lambda i = i: self.count(i)
                self.hFlailBtns[i].image=self.hFlailPictures[i]
                self.hFlailBtns[i].grid(row=1, column = i+2)

        if item==15:
            self.hMightyWeaponBtns = []
            self.hMightyWeaponPictures=(self.might2h1,self.might2h2,self.might2h3,self.might2h4)
            for i in range(len(self.hMightyWeaponPictures)):
                self.hMightyWeaponBtns.append(Button(self.newWindow, image=self.hMightyWeaponPictures[i],bg="#835121"))
                #self.hMightyWeaponBtns[i]["command"]=lambda i = i: self.count(i)
                self.hMightyWeaponBtns[i].image=self.hMightyWeaponPictures[i]
                self.hMightyWeaponBtns[i].grid(row=1, column = i)

            self.btn = Button(self.newWindow, image=self.might2h5, bg="#569522", command = lambda: self.count(0))
            self.btn.image=self.might2h5
            self.btn.grid(row=1,column=5) 

        if item==16:
            self.helmetBtns = []
            self.helmetBtns2= []
            self.helmetPictures = (self.helm1,self.helm2,self.helm3,self.helm4,self.helm5,self.helm6,self.helm7)
            self.helmetPictures2= (self.helm8,self.helm9,self.helm10,self.helm11,self.helm12,self.helm13,self.helm14,self.helm15,self.helm16,self.helm17,self.helm18,self.helm19,self.helm20,self.helm21,self.helm22,self.helm23,self.helm24)
            for i in range(len(self.helmetPictures)):
                self.helmetBtns.append(Button(self.newWindow, image=self.helmetPictures[i],bg="#835121"))
                #self.helmetBtns[i]["command"]=lambda i = i: self.count(i)
                self.helmetBtns[i].image=self.helmetPictures[i]
                self.helmetBtns[i].grid(row=i%3,column=i//3)

            for i in range(len(self.helmetPictures2)):
                self.helmetBtns.append(Button(self.newWindow, image=self.helmetPictures2[i],bg="#569522"))
                #self.helmetBtns[i]["command"]=lambda i = i: self.count(i)
                self.helmetBtns[i].image=self.helmetPictures2[i]
                self.helmetBtns[i].grid(row=i%3,column=i//3)

        if item==17:
            self.spiritStoneBtns = []
            self.spiritStonePictures=(self.spirit1,self.spirit2,self.spirit3,self.spirit4,self.spirit5,self.spirit6,self.spirit7,self.spirit8,self.spirit9,self.spirit10,self.spirit11)
            for i in range(len(self.spiritStonePictures)):
                self.spiritStoneBtns.append(Button(self.newWindow, image=self.spiritStonePictures[i],bg="#835121"))
                #self.spiritStoneBtns[i]["command"]=lambda i = i: self.count(i)
                self.spiritStoneBtns[i].image=self.spiritStonePictures[i]
                self.spiritStoneBtns[i].grid(row=i%2, column = i//2)

            self.btn = Button(self.newWindow, image=self.spirit12, bg="#569522")
            self.btn.image=self.spirit12
            self.btn.grid(row=1,column=5)  

        if item==18:
            self.voodooMaskBtns = []
            self.voodooPictures = (self.voodoo1,self.voodoo2,self.voodoo3,self.voodoo4,self.voodoo5,self.voodoo6,self.voodoo7)
            for i in range(len(self.voodooPictures)):
                self.voodooMaskBtns.append(Button(self.newWindow, image=self.voodooPictures[i],bg="#835121"))
                #self.voodooMaskBtns[i]["command"]=lambda i = i: self.count(i)
                self.voodooMaskBtns[i].image=self.voodooPictures[i]
                self.voodooMaskBtns[i].grid(row=i%2, column = i//2)
                
            self.btn = Button(self.newWindow, image=self.voodoo8, bg="#569522")
            self.btn.image=self.voodoo8
            self.btn.grid(row=1,column=3)    

        if item==19:
            self.diaboBtns = []
            self.diaboPictures = (self.diabo1,self.diabo2,self.diabo3,self.diabo4,self.diabo5,self.diabo6,self.diabo7)
            for i in range(len(self.diaboPictures)):#grid all pictures at once
                self.diaboBtns.append(Button(self.newWindow, image=self.diaboPictures[i],bg="#835121"))
                #self.diaboBtns[i]["command"]=lambda i = i: self.count(i)
                self.diaboBtns[i].image=self.diaboPictures[i]
                self.diaboBtns[i].grid(row=i%2, column = i//2)

            self.btn = Button(self.newWindow, image=self.diabo8, bg="#569522")
            self.btn.image=self.diabo8
            self.btn.grid(row=1,column=3)

        if item==20:
            self.beltBtns = []
            self.beltPictures = (self.belt1,self.belt2,self.belt3,self.belt4,self.belt5,self.belt6,self.belt7,self.belt8,self.belt9,self.belt10,
                                 self.belt11,self.belt12,self.belt13,self.belt14,self.belt15,self.belt16,self.belt17,self.belt18,self.belt19,self.belt20,
                                 self.belt21,self.belt22)
            for i in range(len(self.beltPictures)):#grid all pictures at once
                self.beltBtns.append(Button(self.newWindow, image=self.beltPictures[i],bg="#835121"))
                #self.beltBtns[i]["command"]=lambda i = i: self.count(i)
                self.beltBtns[i].image=self.beltPictures[i]
                self.beltBtns[i].grid(row=i%6, column = i//6)

            self.btn = Button(self.newWindow, image=self.belt23, bg="#569522")
            self.btn.image=self.belt23
            self.btn.grid(row=4,column=3)

            self.btn = Button(self.newWindow, image=self.belt24, bg="#569522")
            self.btn.image=self.belt24
            self.btn.grid(row=5,column=3)

            self.btn = Button(self.newWindow, image=self.belt25, bg="#569522")
            self.btn.image=self.belt25
            self.btn.grid(row=6,column=0)

            self.btn = Button(self.newWindow, image=self.belt26, bg="#569522")
            self.btn.image=self.belt26
            self.btn.grid(row=6,column=1)

        if item==21:
            self.mightyBeltBtns = []
            self.mightyBeltPictures = (self.mightbelt1,self.mightbelt2,self.mightbelt3,self.mightbelt4,self.mightbelt5,self.mightbelt6,self.mightbelt7)
            for i in range(len(self.mightyBeltPictures)):#grid all pictures at once
                self.mightyBeltBtns.append(Button(self.newWindow, image=self.mightyBeltPictures[i],bg="#835121"))
                #self.mightyBeltBtns[i]["command"]=lambda i = i: self.count(i)
                self.mightyBeltBtns[i].image=self.mightyBeltPictures[i]
                self.mightyBeltBtns[i].grid(row=i%2, column = i//2)

            self.btn = Button(self.newWindow, image=self.mightbelt8, bg="#569522")
            self.btn.image=self.mightbelt8
            self.btn.grid(row=1,column=3)

        if item==22:
            self.pantsBtns = []
            self.pantsPictures = (self.pants5,self.pants6,self.pants7,self.pants8,self.pants9,self.pants10,
                                  self.pants11,self.pants12,self.pants13,self.pants14,self.pants15,self.pants16,self.pants17,self.pants18,self.pants19,self.pants20,
                                  self.pants21,self.pants22)
            for i in range(len(self.pantsPictures)):#grid all pictures at once
                self.pantsBtns.append(Button(self.newWindow, image=self.pantsPictures[i],bg="#569522"))
                #self.pantsBtns[i]["command"]=lambda i = i: self.count(i)
                self.pantsBtns[i].image=self.pantsPictures[i]
                self.pantsBtns[i].grid(row=i%3, column = i//3)

            self.btn = Button(self.newWindow, image=self.pants1, bg="#835121")
            self.btn.image=self.pants1
            self.btn.grid(row=6,column=1)

            self.btn = Button(self.newWindow, image=self.pants2, bg="#835121")
            self.btn.image=self.pants2
            self.btn.grid(row=6,column=2)

            self.btn = Button(self.newWindow, image=self.pants3, bg="#835121")
            self.btn.image=self.pants3
            self.btn.grid(row=6,column=3)

            self.btn = Button(self.newWindow, image=self.pants4, bg="#835121")
            self.btn.image=self.pants4
            self.btn.grid(row=6,column=4)
                
        if item==23:
            self.bootBtns = []
            self.bootBtns2 = []
            self.bootPictures = (self.boots1,self.boots2,self.boots3,self.boots4,self.boots5,self.boots6,self.boots7)
            self.bootPictures2 = (self.boots8,self.boots9,self.boots10,self.boots11,self.boots12,self.boots13,self.boots14,self.boots15,self.boots16,self.boots17,self.boots18,self.boots19,self.boots20,
                                 self.boots21,self.boots22,self.boots23,self.boots24,self.boots25)
            for i in range(len(self.bootPictures)):#grid all pictures at once
                self.bootBtns.append(Button(self.newWindow, image=self.bootPictures[i],bg="#835121"))
                #self.bootBtns[i]["command"]=lambda i = i: self.count(i)
                self.bootBtns[i].image=self.bootPictures[i]
                self.bootBtns[i].grid(row=i%3, column = i//3)

            for i in range(len(self.bootPictures2)):#grid all pictures at once
                self.bootBtns2.append(Button(self.newWindow, image=self.bootPictures2[i],bg="#569522"))
                #self.bootBtns2[i]["command"]=lambda i = i: self.count(i)
                self.bootBtns2[i].image=self.bootPictures2[i]
                self.bootBtns2[i].grid(row=(i+3)%3, column = (i+9)//3)
                 
        if item==24:
            self.amuletBtns = []
            self.amuletPictures = (self.amulet1,self.amulet2,self.amulet3,self.amulet4,self.amulet5,self.amulet6,self.amulet7,self.amulet8,self.amulet9,self.amulet10,
                                   self.amulet11,self.amulet12,self.amulet13,self.amulet14,self.amulet15,self.amulet16,self.amulet17,self.amulet18,self.amulet19)
            for i in range(len(self.amuletPictures)):#grid all pictures at once
                self.amuletBtns.append(Button(self.newWindow, image=self.amuletPictures[i],bg="#835121"))
                #self.amuletBtns[i]["command"]=lambda i = i: self.count(i)
                self.amuletBtns[i].image=self.amuletPictures[i]
                self.amuletBtns[i].grid(row=i%2, column = i//2)

            self.btn = Button(self.newWindow, image=self.amulet20, bg="#569522")
            self.btn.image=self.amulet20
            self.btn.grid(row=1,column=9)

            self.btn = Button(self.newWindow, image=self.amulet21, bg="#569522")
            self.btn.image=self.amulet21
            self.btn.grid(row=1,column=10)

            self.btn = Button(self.newWindow, image=self.amulet22, bg="#569522")
            self.btn.image=self.amulet22
            self.btn.grid(row=0,column=10)

            self.btn = Button(self.newWindow, image=self.amulet23, bg="#569522")
            self.btn.image=self.amulet23
            self.btn.grid(row=0,column=11)
                  
        if item==25:
            self.ringBtns = []
            self.ringBtns2 = []
            self.ringPictures = (self.ring1,self.ring2,self.ring3,self.ring4,self.ring5,self.ring6,self.ring7,self.ring8,self.ring9,self.ring10,
                                 self.ring11,self.ring12,self.ring13,self.ring14,self.ring15,self.ring16,self.ring17,self.ring18,self.ring19,self.ring20,
                                 self.ring21,self.ring22,self.ring23,self.ring24,self.ring25)

            self.ringPictures2= (self.ring26,self.ring27,self.ring28,self.ring29,self.ring30,
                                 self.ring31,self.ring32)

            for i in range(len(self.ringPictures)):#grid all pictures at once
                self.ringBtns.append(Button(self.newWindow, image=self.ringPictures[i],bg="#835121"))
                #self.ringBtns[i]["command"]=lambda i = i: self.count(i)
                self.ringBtns[i].image=self.ringPictures[i]
                self.ringBtns[i].grid(row=i%2, column = i//2)

            for i in range(len(self.ringPictures2)):#grid all pictures at once
                self.ringBtns2.append(Button(self.newWindow, image=self.ringPictures2[i],bg="#569522"))
                #self.ringBtns2[i]["command"]=lambda i = i: self.count(i)
                self.ringBtns2[i].image=self.ringPictures2[i]
                self.ringBtns2[i].grid(row=(i+23)%2, column = (i+23)//2)

        if item==26:
            self.shieldBtns = []
            self.shieldPictures = (self.shield1,self.shield2,self.shield3,self.shield4,self.shield5,self.shield6,self.shield7,self.shield8)
            for i in range(len(self.shieldPictures)):#grid all pictures at once
                self.shieldBtns.append(Button(self.newWindow, image=self.shieldPictures[i],bg="#835121"))
                #self.shieldBtns[i]["command"]=lambda i = i: self.count(i)
                self.shieldBtns[i].image=self.shieldPictures[i]
                self.shieldBtns[i].grid(row=1, column = i+2)
                
        if item==27:
            self.crusaderShieldBtns = []
            self.crusaderShieldPictures = (self.crusshield1,self.crusshield2,self.crusshield3,self.crusshield4,self.crusshield5,self.crusshield6,self.crusshield7,self.crusshield8)
            for i in range(len(self.crusaderShieldPictures)):#grid all pictures at once
                self.crusaderShieldBtns.append(Button(self.newWindow, image=self.crusaderShieldPictures[i],bg="#835121"))
                #self.crusaderShieldBtns[i]["command"]=lambda i = i: self.count(i)
                self.crusaderShieldBtns[i].image=self.crusaderShieldPictures[i]
                self.crusaderShieldBtns[i].grid(row=1, column = i+2)
                
        if item==28:
            self.mojoBtns = []
            self.mojoPictures = (self.mojo1,self.mojo2,self.mojo3,self.mojo4,self.mojo5)
            for i in range(len(self.mojoPictures)):#grid all pictures at once
                self.mojoBtns.append(Button(self.newWindow, image=self.mojoPictures[i],bg="#835121"))
                #self.mojoBtns[i]["command"]=lambda i = i: self.count(i)
                self.mojoBtns[i].image=self.mojoPictures[i]
                self.mojoBtns[i].grid(row=1, column = i+2)

            self.btn = Button(self.newWindow, image=self.mojo6, bg="#569522")
            self.btn.image=self.mojo6
            self.btn.grid(row=1,column=23)

            self.btn = Button(self.newWindow, image=self.mojo7, bg="#569522")
            self.btn.image=self.mojo7
            self.btn.grid(row=1,column=24)
            
        if item==29:
            self.orbBtns = []
            self.orbPictures = (self.orb4,self.orb5,self.orb6,self.orb7,self.orb8,self.orb9)
            for i in range(len(self.orbPictures)):#grid all pictures at once
                self.orbBtns.append(Button(self.newWindow, image=self.orbPictures[i],bg="#835121"))
                #self.orbBtns[i]["command"]=lambda i = i: self.count(i)
                self.orbBtns[i].image=self.orbPictures[i]
                self.orbBtns[i].grid(row=1, column = i+2)

            self.btn = Button(self.newWindow, image=self.orb1, bg="#569522")
            self.btn.image=self.orb1
            self.btn.grid(row=1,column=12)

            self.btn = Button(self.newWindow, image=self.orb2, bg="#569522")
            self.btn.image=self.orb2
            self.btn.grid(row=1,column=13)

            self.btn = Button(self.newWindow, image=self.orb3, bg="#569522")
            self.btn.image=self.orb3
            self.btn.grid(row=1,column=14)

        if item==30:
            self.quiverBtns = []
            self.quiverPictures = (self.quiver1,self.quiver2,self.quiver3,self.quiver4,self.quiver5,self.quiver6,self.quiver7,self.quiver8,self.quiver9)
            for i in range(len(self.quiverPictures)):#grid all pictures at once
                self.quiverBtns.append(Button(self.newWindow, image=self.quiverPictures[i],bg="#835121"))
                #self.quiverBtns[i]["command"]=lambda i = i: self.count(i)
                self.quiverBtns[i].image=self.quiverPictures[i]
                self.quiverBtns[i].grid(row=1, column = i+2)
                
        if item==31:
            self.followerBtns = []
            self.followerPictures = (self.follower1,self.follower2,self.follower3)
            for i in range(len(self.followerPictures)):#grid all pictures at once
                self.followerBtns.append(Button(self.newWindow, image=self.followerPictures[i],bg="#835121"))
                #self.followerBtns[i]["command"]=lambda i = i: self.count(i)
                self.followerBtns[i].image=self.followerPictures[i]
                self.followerBtns[i].grid(row=1, column = i+2)
                
        if item==32:
            self.miscBtns = []
            self.miscPictures = (self.misc1,self.misc2)
            for i in range(len(self.miscPictures)):#grid all pictures at once
                self.miscBtns.append(Button(self.newWindow, image=self.miscPictures[i],bg="#835121"))
                #self.miscBtns[i]["command"]=lambda i = i: self.count(i)
                self.miscBtns[i].image=self.miscPictures[i]
                self.miscBtns[i].grid(row=1, column = i+2)
                
        if item==33:
            self.wizardHatBtns = []
            self.wizardHatPictures = (self.wizhat1,self.wizhat2,self.wizhat3,self.wizhat4,self.wizhat5,self.wizhat6,self.wizhat7)
            for i in range(len(self.wizardHatPictures)):#grid all pictures at once
                self.wizardHatBtns.append(Button(self.newWindow, image=self.wizardHatPictures[i],bg="#835121"))
                #self.wizardHatBtns[i]["command"]=lambda i = i: self.count(i)
                self.wizardHatBtns[i].image=self.wizardHatPictures[i]
                self.wizardHatBtns[i].grid(row=1, column = i+2)
                
        if item==34:
            self.shoulderBtns = []
            self.shoulderPictures = (self.shoulder1,self.shoulder2,self.shoulder3,self.shoulder4,self.shoulder5,self.shoulder6,self.shoulder7,self.shoulder8,self.shoulder9,self.shoulder10,
                                     self.shoulder11,self.shoulder12,self.shoulder13,self.shoulder14,self.shoulder15,self.shoulder16,self.shoulder17,self.shoulder18,self.shoulder19)
            for i in range(len(self.shoulderPictures)):#grid all pictures at once
                if i < 5:
                    self.shoulderBtns.append(Button(self.newWindow, image=self.shoulderPictures[i],bg="#835121"))
                    #self.shoulderBtns[i]["command"]=lambda i = i: self.count(i)
                    self.shoulderBtns[i].image=self.shoulderPictures[i]
                    self.shoulderBtns[i].grid(row=i%2, column = i//2)
                else:
                    self.shoulderBtns.append(Button(self.newWindow, image=self.shoulderPictures[i],bg="#569522"))
                    #self.shoulderBtns[i]["command"]=lambda i = i: self.count(i)
                    self.shoulderBtns[i].image=self.shoulderPictures[i]
                    self.shoulderBtns[i].grid(row=i%2, column = i//2)
                    
        if item==35:
            self.chestplateBtns = []
            self.chestplatePictures = (self.chest1,self.chest2,self.chest3,self.chest4,self.chest5,self.chest6,self.chest7,self.chest8,self.chest9,self.chest10,
                                       self.chest11,self.chest12,self.chest13,self.chest14,self.chest15,self.chest16,self.chest17,self.chest18,self.chest19,self.chest20,
                                       self.chest21,self.chest22,self.chest23,self.chest24,self.chest25)
            for i in range(len(self.chestplatePictures)):#grid all pictures at once
                if i < 8:
                    self.chestplateBtns.append(Button(self.newWindow, image=self.chestplatePictures[i],bg="#835121"))
                    #self.chestplateBtns[i]["command"]=lambda i = i: self.count(i)
                    self.chestplateBtns[i].image=self.chestplatePictures[i]
                    self.chestplateBtns[i].grid(row=i%3, column = i//3)
                else:
                    self.chestplateBtns.append(Button(self.newWindow, image=self.chestplatePictures[i],bg="#569522"))
                    #self.chestplateBtns[i]["command"]=lambda i = i: self.count(i)
                    self.chestplateBtns[i].image=self.chestplatePictures[i]
                    self.chestplateBtns[i].grid(row=i%3, column = i//3)
                    
        if item==36:
            self.cloakBtns = []
            self.cloakPictures = (self.cloak1,self.cloak2,self.cloak3,self.cloak4,self.cloak5,self.cloak6)
            for i in range(len(self.cloakPictures)):#grid all pictures at once
                if i < 4:
                    self.cloakBtns.append(Button(self.newWindow, image=self.cloakPictures[i],bg="#835121"))
                    #self.cloakBtns[i]["command"]=lambda i = i: self.count(i)
                    self.cloakBtns[i].image=self.cloakPictures[i]
                    self.cloakBtns[i].grid(row=1, column = i+2)
                else:
                    self.cloakBtns.append(Button(self.newWindow, image=self.cloakPictures[i],bg="#569522"))
                    #self.cloakBtns[i]["command"]=lambda i = i: self.count(i)
                    self.cloakBtns[i].image=self.cloakPictures[i]
                    self.cloakBtns[i].grid(row=1, column = i+2)
                    
        if item==37:
            self.bracerBtns = []
            self.bracerPictures = (self.bracers1,self.bracers2,self.bracers3,self.bracers4,self.bracers5,self.bracers6,self.bracers7,self.bracers8,self.bracers9,self.bracers10,
                                   self.bracers11,self.bracers12,self.bracers13,self.bracers14,self.bracers15)
            for i in range(len(self.bracerPictures)):#grid all pictures at once
                if i < 13:
                    self.bracerBtns.append(Button(self.newWindow, image=self.bracerPictures[i],bg="#835121"))
                    #self.bracerBtns[i]["command"]=lambda i = i: self.count(i)
                    self.bracerBtns[i].image=self.bracerPictures[i]
                    self.bracerBtns[i].grid(row=i%3, column = i//3)
                else:
                    self.bracerBtns.append(Button(self.newWindow, image=self.bracerPictures[i],bg="#569522"))
                    #self.bracerBtns[i]["command"]=lambda i = i: self.count(i)
                    self.bracerBtns[i].image=self.bracerPictures[i]
                    self.bracerBtns[i].grid(row=i%3, column = i//3)
                    
        if item==38:
            self.glovesBtns = []
            self.glovesPictures = (self.gloves1,self.gloves2,self.gloves3,self.gloves4,self.gloves5,self.gloves6,self.gloves7,self.gloves8,self.gloves9,self.gloves10,
                                   self.gloves11,self.gloves12,self.gloves13,self.gloves14,self.gloves15,self.gloves16,self.gloves17,self.gloves18,self.gloves19,self.gloves20,
                                   self.gloves21,self.gloves22,self.gloves23,self.gloves24,self.gloves25,self.gloves26,self.gloves27)
            for i in range(len(self.glovesPictures)):#grid all pictures at once
                if i < 6:
                    self.glovesBtns.append(Button(self.newWindow, image=self.glovesPictures[i],bg="#835121"))
                    #self.glovesBtns[i]["command"]=lambda i = i: self.count(i)
                    self.glovesBtns[i].image=self.glovesPictures[i]
                    self.glovesBtns[i].grid(row=i%4, column = i//4)
                else:
                    self.glovesBtns.append(Button(self.newWindow, image=self.glovesPictures[i],bg="#569522"))
                    #self.glovesBtns[i]["command"]=lambda i = i: self.count(i)
                    self.glovesBtns[i].image=self.glovesPictures[i]
                    self.glovesBtns[i].grid(row=i%4, column = i//4)
                
    def count(self, number):
        f = open("dropper.dat", "rb")#open the file which pickle will save to
        
        try:#this tries to load the files from the pickle file, if any of the files don't exist then it goes to the except case
            [self.__dropNumber,self.__axe1total,self.__axe2total,self.__axe3total,self.__axe4total,self.__axe5total,self.__axe6total,self.__mace1total,self.__mace2total,self.__mace3total,
             self.__mace4total,self.__mace5total,self.__mace6total,self.__mace7total,self.__mace8total,self.__mace9total,self.__dagger1total,self.__dagger2total,self.__dagger3total,self.__dagger4total
             ,self.__dagger5total,self.__dagger6total,self.__spear1total,self.__spear2total,self.__spear3total,self.__spear4total,self.__spear5total,self.__sword1total,self.__sword2total,self.__sword3total,self.__sword4total
             ,self.__sword5total,self.__sword6total,self.__sword7total,self.__sword8total,self.__sword9total,self.__sword10total,self.__sword11total,self.__sword12total,self.__sword13total,self.__sword14total,self.__sword15total,
             self.__sword16total,self.__sword17total,self.__ck1total,self.__ck2total,self.__ck3total,self.__ck4total,self.__ck5total,self.__ck6total,self.__ck7total,self.__ck8total,self.__ck9total,self.__ck10total]=pickle.load(f)
        except:#simply sets all item variables to zero as if it is a new log
            self.__dropNumber=self.__axe1total=self.__axe2total=self.__axe3total=self.__axe4total=self.__axe5total=self.__axe6total=self.__mace1total=self.__mace2total=self.__mace3total=self.__mace4total=self.__mace5total=self.__mace6total=self.__mace7total=self.__mace8total=self.__mace9total = 0
            self.__dagger1total=self.__dagger2total=self.__dagger3total=self.__dagger4total=self.__dagger5total=self.__dagger6total=self.__spear1total=self.__spear2total=self.__spear3total=self.__spear4total=self.__spear5total=self.__sword16total=self.__sword17total=0
            self.__sword1total=self.__sword2total=self.__sword3total=self.__sword4total=self.__sword5total=self.__sword6total=self.__sword7total=self.__sword8total=self.__sword9total=self.__sword10total=self.__sword11total=self.__sword12total=self.__sword13total=self.__sword14total=self.__sword15total=0
            self.__ck1total=self.__ck2total=self.__ck3total=self.__ck4total=self.__ck5total=self.__ck6total=self.__ck7total=self.__ck8total=self.__ck9total=self.__ck10total=0
            
        if 0 <= number <= 5:# based on which item is clicked, increment both it and the total number of items
            if number == 0:
                self.__dropNumber += 1
                self.__axe1total += 1
                
            elif number == 1:
                self.__dropNumber += 1
                self.__axe2total += 1

            elif number == 2:
                self.__dropNumber += 1
                self.__axe3total += 1

            elif number == 3:
                self.__dropNumber += 1
                self.__axe4total += 1

            elif number == 4:
                self.__dropNumber += 1
                self.__axe5total += 1

            elif number == 5:
                self.__dropNumber += 1
                self.__axe6total += 1#reappend all of the drop rates every time the count function is executed in order to update variables
                
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe6total/self.__dropNumber))).grid(row=11,column=5)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe1total/self.__dropNumber))).grid(row=11,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe2total/self.__dropNumber))).grid(row=11,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe3total/self.__dropNumber))).grid(row=11,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe4total/self.__dropNumber))).grid(row=11,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__axe5total/self.__dropNumber))).grid(row=11,column=4)

        if 5 <number <= 14:#same thing for every item, very repetitive
            if number == 6:
                self.__dropNumber += 1
                self.__mace1total += 1
                
            elif number == 7:
                self.__dropNumber += 1
                self.__mace2total += 1
                
            elif number == 8:
                self.__dropNumber += 1
                self.__mace3total += 1
                
            elif number == 9:
                self.__dropNumber += 1
                self.__mace4total += 1
                
            elif number == 10:
                self.__dropNumber += 1
                self.__mace5total += 1
                
            elif number == 11:
                self.__dropNumber += 1
                self.__mace6total += 1
                
            elif number == 12:
                self.__dropNumber += 1
                self.__mace7total += 1
                
            elif number == 13:
                self.__dropNumber += 1
                self.__mace8total += 1
                
            elif number == 14:
                self.__dropNumber += 1
                self.__mace9total += 1

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace1total/self.__dropNumber))).grid(row=11,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace2total/self.__dropNumber))).grid(row=11,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace3total/self.__dropNumber))).grid(row=11,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace4total/self.__dropNumber))).grid(row=11,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace5total/self.__dropNumber))).grid(row=11,column=4)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace6total/self.__dropNumber))).grid(row=11,column=5)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace7total/self.__dropNumber))).grid(row=11,column=6)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace8total/self.__dropNumber))).grid(row=11,column=7)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__mace9total/self.__dropNumber))).grid(row=11,column=8)
            
        if 14<number<=20:
            if number == 15:
                self.__dropNumber += 1
                self.__dagger1total += 1

            elif number == 16:
                self.__dropNumber += 1
                self.__dagger2total += 1

            elif number == 17:
                self.__dropNumber += 1
                self.__dagger3total += 1

            elif number == 18:
                self.__dropNumber += 1
                self.__dagger4total += 1
                
            elif number == 19:
                self.__dropNumber += 1
                self.__dagger5total += 1                
                
            elif number == 20:
                self.__dropNumber += 1
                self.__dagger6total += 1                

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger1total/self.__dropNumber))).grid(row=11,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger2total/self.__dropNumber))).grid(row=11,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger3total/self.__dropNumber))).grid(row=11,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger4total/self.__dropNumber))).grid(row=11,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__dagger5total/self.__dropNumber))).grid(row=11,column=4)
            
        if 20<number<=25:
            if number == 21:
                self.__dropNumber += 1
                self.__spear1total += 1
                
            elif number == 22:
                self.__dropNumber += 1
                self.__spear2total += 1
                
            elif number == 23:
                self.__dropNumber += 1
                self.__spear3total += 1
                
            elif number == 24:
                self.__dropNumber += 1
                self.__spear4total += 1
                
            elif number == 25:
                self.__dropNumber += 1
                self.__spear5total += 1

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear1total/self.__dropNumber))).grid(row=11,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear2total/self.__dropNumber))).grid(row=11,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear3total/self.__dropNumber))).grid(row=11,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear4total/self.__dropNumber))).grid(row=11,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__spear5total/self.__dropNumber))).grid(row=11,column=4)
            
        if 25<number<=42:
            if number == 26:
                self.__dropNumber += 1
                self.__sword1total += 1
                
            elif number == 27:
                self.__dropNumber += 1
                self.__sword2total += 1
                
            elif number == 28:
                self.__dropNumber += 1
                self.__sword3total += 1
                
            elif number == 29:
                self.__dropNumber += 1
                self.__sword4total += 1
                
            elif number == 30:
                self.__dropNumber += 1
                self.__sword5total += 1
                
            elif number == 31:
                self.__dropNumber += 1
                self.__sword6total += 1
                
            elif number == 32:
                self.__dropNumber += 1
                self.__sword7total += 1
                
            elif number == 33:
                self.__dropNumber += 1
                self.__sword8total += 1
                
            elif number == 34:
                self.__dropNumber += 1
                self.__sword9total += 1
                
            elif number == 35:
                self.__dropNumber += 1
                self.__sword10total += 1
                
            elif number == 36:
                self.__dropNumber += 1
                self.__sword11total += 1
                
            elif number == 37:
                self.__dropNumber += 1
                self.__sword12total += 1
                
            elif number == 38:
                self.__dropNumber += 1
                self.__sword13total += 1
                
            elif number == 39:
                self.__dropNumber += 1
                self.__sword14total += 1
                
            elif number == 40:
                self.__dropNumber += 1
                self.__sword15total += 1
                
            elif number == 41:
                self.__dropNumber += 1
                self.__sword16total += 1
                
            elif number == 42:
                self.__dropNumber += 1
                self.__sword17total += 1
                
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword1total/self.__dropNumber))).grid(row=0,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword2total/self.__dropNumber))).grid(row=3,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword3total/self.__dropNumber))).grid(row=0,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword4total/self.__dropNumber))).grid(row=3,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword5total/self.__dropNumber))).grid(row=0,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword6total/self.__dropNumber))).grid(row=3,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword7total/self.__dropNumber))).grid(row=0,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword8total/self.__dropNumber))).grid(row=3,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword9total/self.__dropNumber))).grid(row=0,column=4)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword10total/self.__dropNumber))).grid(row=3,column=4)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword11total/self.__dropNumber))).grid(row=0,column=5)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword12total/self.__dropNumber))).grid(row=3,column=5)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword13total/self.__dropNumber))).grid(row=0,column=6)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword14total/self.__dropNumber))).grid(row=3,column=6)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword15total/self.__dropNumber))).grid(row=0,column=7)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword16total/self.__dropNumber))).grid(row=3,column=7)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__sword17total/self.__dropNumber))).grid(row=0,column=8)
            
        if 42<number<=52:        
            if number == 43:
                self.__dropNumber += 1
                self.__ck1total += 1

            elif number == 44:
                self.__dropNumber += 1
                self.__ck2total += 1

            elif number == 45:
                self.__dropNumber += 1
                self.__ck3total += 1

            elif number == 46:
                self.__dropNumber += 1
                self.__ck4total += 1

            elif number == 47:
                self.__dropNumber += 1
                self.__ck5total += 1

            elif number == 48:
                self.__dropNumber += 1
                self.__ck6total += 1

            elif number == 49:
                self.__dropNumber += 1
                self.__ck7total += 1

            elif number == 50:
                self.__dropNumber += 1
                self.__ck8total += 1

            elif number == 51:
                self.__dropNumber += 1
                self.__ck9total += 1

            elif number == 52:
                self.__dropNumber += 1
                self.__ck10total += 1

            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck1total/self.__dropNumber))).grid(row=0,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck2total/self.__dropNumber))).grid(row=3,column=0)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck3total/self.__dropNumber))).grid(row=0,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck4total/self.__dropNumber))).grid(row=3,column=1)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck5total/self.__dropNumber))).grid(row=0,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck6total/self.__dropNumber))).grid(row=3,column=2)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck7total/self.__dropNumber))).grid(row=0,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck8total/self.__dropNumber))).grid(row=3,column=3)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck9total/self.__dropNumber))).grid(row=0,column=4)
            Label(self.newWindow, text="{:.2f}%".format(100*(self.__ck10total/self.__dropNumber))).grid(row=0,column=4)
       
        #open the file is write binary this time and create a list of variables to store in the file using pickle
        f = open("dropper.dat", "wb")
        storage = [self.__dropNumber,self.__axe1total,self.__axe2total,self.__axe3total,self.__axe4total,self.__axe5total,self.__axe6total,self.__mace1total,
                   self.__mace2total,self.__mace3total,self.__mace4total,self.__mace5total,self.__mace6total,self.__mace7total,self.__mace8total,self.__mace9total,
                   self.__dagger1total,self.__dagger2total,self.__dagger3total,self.__dagger4total,self.__dagger5total,self.__dagger6total,self.__spear1total,self.__spear2total
                   ,self.__spear3total,self.__spear4total,self.__spear5total,self.__sword1total,self.__sword2total,self.__sword3total,self.__sword4total
             ,self.__sword5total,self.__sword6total,self.__sword7total,self.__sword8total,self.__sword9total,self.__sword10total,self.__sword11total,self.__sword12total,self.__sword13total,self.__sword14total,self.__sword15total
                   ,self.__sword16total,self.__sword17total,self.__ck1total,self.__ck2total,self.__ck3total,self.__ck4total,self.__ck5total,self.__ck6total,self.__ck7total,self.__ck8total,self.__ck9total,self.__ck10total]
        pickle.dump(storage, f)
        f.close    #close the file      
        Label(self, text="Total Drops: {}".format(self.__dropNumber)).grid(row=19,column=1)#update total drops when count is run

def main():#main function runs and loops
    app=dropLog()
    app.mainloop()
    
if __name__ == "__main__":#only run when namespace is main
    main()
